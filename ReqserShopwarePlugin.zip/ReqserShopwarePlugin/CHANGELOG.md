# Changelog

## 2.0.0 - 09.2025
- New Major Version only for Shopware >= 6.6
- SEO Friendly Redirect
- Improved performance and caching

## 1.7.0 - 09.2025
- Legacy Version for Shopware 6.4 and 6.5
- Similar Logic to 2.0.0

## 1.5.0
- Improved redirect settings

## 1.4.0
- Added auto update functionality

## 1.3.0
- Redirect
- Support Shopware >= 6.6

## 1.2.0
- Notifications and Snippet Handler

## 1.0.0
- Snippet Handling
