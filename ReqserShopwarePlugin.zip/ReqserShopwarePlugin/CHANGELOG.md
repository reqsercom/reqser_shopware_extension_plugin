# Changelog

## 1.6.0
- Reduce Loading Time on Redirect

## 1.5.0
- Improved redirect settings

## 1.4.0
- Added auto update functionality

## 1.3.0
- Redirect
- Support Shopware >= 6.6

## 1.2.0
- Notifications and Snippet Handler

## 1.0.0
- Snippet Handling
