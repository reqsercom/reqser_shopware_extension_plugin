# Changelog
## 1.5.65.0
- Version based on 1.5.0 only for Shopware <=6.5

## 1.5.0
- Improved redirect settings

## 1.4.0
- Added auto update functionality

## 1.3.0
- Redirect
- Support Shopware >= 6.6

## 1.2.0
- Notifications and Snippet Handler

## 1.0.0
- Snippet Handling
