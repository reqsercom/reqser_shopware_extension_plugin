<?php declare(strict_types=1);

namespace Reqser\Plugin\Subscriber;

use Reqser\Plugin\Service\ReqserWebhookService;
use Shopware\Core\Framework\DataAbstractionLayer\EntityRepository;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Criteria;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\EqualsFilter;
use Shopware\Core\Framework\DataAbstractionLayer\Search\Filter\NotFilter;
use Shopware\Core\System\SalesChannel\SalesChannelContext;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpFoundation\RequestStack;
use Symfony\Component\HttpKernel\Event\ResponseEvent;
use Symfony\Component\HttpKernel\KernelEvents;

class ReqserLanguageSwitchSubscriber implements EventSubscriberInterface
{
    private $domainRepository;
    private $requestStack;
    private $webhookService;
    
    public function __construct(
        RequestStack $requestStack, 
        EntityRepository $domainRepository,
        ReqserWebhookService $webhookService)
    {
        $this->requestStack = $requestStack;
        $this->domainRepository = $domainRepository;
        $this->webhookService = $webhookService;
    }

    public static function getSubscribedEvents(): array
    {
        return [
            KernelEvents::RESPONSE => 'onKernelResponse'
        ];
    }

    public function onKernelResponse(ResponseEvent $event): void
    {
        $request = $event->getRequest();
        $domainId = $request->attributes->get('sw-domain-id');
        $currentRoute = $request->attributes->get('_route');

        if ($currentRoute !== 'frontend.checkout.switch-language' || $domainId === null) {
            //$this->webhookService->sendErrorToWebhook(['type' => 'debug', 'info' => 'Not a language switch request', 'currentRoute' => $currentRoute, 'domain_id' => $domainId, 'file' => __FILE__, 'line' => __LINE__]);
            return;
        }

        $this->webhookService->sendErrorToWebhook(['type' => 'debug', 'info' => 'Language switch request', 'currentRoute' => $currentRoute, 'domain_id' => $domainId, 'file' => __FILE__, 'line' => __LINE__]);

        /*
        // Retrieve sales channel domains for the current context
        $salesChannelDomains = $this->getSalesChannelDomains($event->getSalesChannelContext());
        $currentDomain = $salesChannelDomains->get($domainId);
        if (!$currentDomain) {
            return;
        }

        $customFields = $currentDomain->getCustomFields();
        $debugMode = true;
        if (isset($customFields['ReqserRedirect']['debugMode']) && $customFields['ReqserRedirect']['debugMode'] === true) {
            $debugMode = true;
            $this->webhookService->sendErrorToWebhook(['type' => 'debug', 'info' => 'Debug Mode activated', 'domain_id' => $currentDomain, 'file' => __FILE__, 'line' => __LINE__]);
        }
        */

        $this->webhookService->sendErrorToWebhook(['type' => 'debug', 'info' => 'Setting domain user override', 'domainId' => $domainId, 'file' => __FILE__, 'line' => __LINE__]);
        $this->requestStack->getSession()->set('reqser_redirect_domain_user_override', $domainId);
    }

    private function getSalesChannelDomains(SalesChannelContext $context)
    {
        // Retrieve the full collection without limiting to the current sales channel
        $criteria = new Criteria();
        
        // Ensure we're only retrieving domains that have the 'ReqserRedirect' custom field set
        $criteria->addFilter(new NotFilter(NotFilter::CONNECTION_AND, [
            new EqualsFilter('customFields.ReqserRedirect', null)
        ]));
    
        // Get the collection from the repository
        return $this->domainRepository->search($criteria, $context->getContext())->getEntities();
    }
}
